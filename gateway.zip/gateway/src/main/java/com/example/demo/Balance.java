package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class Balance {

	  @GetMapping(value = "/bal")
	public String getBal()
	{
		System.out.println("*********");
		return "Tahsnks ===";
	}
	  @GetMapping(value = "/dbfav")
		public String getdbfav()
		{
			System.out.println("*********");
			return "db fav ===";
		}
}
